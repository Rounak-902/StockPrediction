import matplotlib.pyplot as plt
import matplotlib.patches as patches

# Create a new figure
fig, ax = plt.subplots(figsize=(10, 8))
ax.set_xlim(0, 10)
ax.set_ylim(0, 14)
ax.axis('off')

# Function to add a rectangle to the plot
def add_rectangle(x, y, text):
    rect = patches.Rectangle((x, y), 6, 1.5, linewidth=1, edgecolor='black', facecolor='lightblue')
    ax.add_patch(rect)
    ax.text(x + 3, y + 0.75, text, horizontalalignment='center', verticalalignment='center', fontsize=10)

# Function to add a decision diamond to the plot
def add_diamond(x, y, text):
    diamond = patches.Polygon([[x + 3, y + 1.5], [x + 6, y + 0.75], [x + 3, y], [x, y + 0.75]], 
                              closed=True, edgecolor='black', facecolor='lightyellow')
    ax.add_patch(diamond)
    ax.text(x + 3, y + 0.75, text, horizontalalignment='center', verticalalignment='center', fontsize=10)

# Function to add an oval (start/end) to the plot
def add_oval(x, y, text):
    oval = patches.Ellipse((x + 3, y + 0.75), 6, 1.5, edgecolor='black', facecolor='lightgreen')
    ax.add_patch(oval)
    ax.text(x + 3, y + 0.75, text, horizontalalignment='center', verticalalignment='center', fontsize=10)

# Function to add arrows between shapes
def add_arrow(x1, y1, x2, y2):
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(facecolor='black', arrowstyle='->'))

# Add flowchart components
add_oval(2, 12, 'Start')
add_arrow(5, 11.25, 5, 10.75)
add_rectangle(2, 10, 'Collect Historical Stock Data (Kaggle)')
add_arrow(5, 9.25, 5, 8.75)
add_rectangle(2, 8, 'Preprocess Data (Clean, Normalize)')
add_arrow(5, 7.25, 5, 6.75)
add_diamond(2, 6, 'Model Selection')
add_arrow(5.75, 5.75, 8.5, 5.75)
add_rectangle(7, 5, 'Linear Regression')
add_arrow(5, 5.25, 5, 3.75)
add_rectangle(2, 4, 'Decision Tree')
add_arrow(5, 3.25, 5, 2.75)
add_rectangle(2, 2, 'Train Model with Features')
add_arrow(5, 1.25, 5, 0.75)
add_rectangle(2, 0, 'Evaluate Model (MSE, MAE, R²)')
add_arrow(5, -0.75, 5, -1.25)
add_oval(2, -2, 'End')

plt.show()
