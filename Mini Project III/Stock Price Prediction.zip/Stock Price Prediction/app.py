from flask import Flask, render_template, request
import yfinance as yf
import pickle
import numpy as np
import plotly.graph_objs as go
import plotly.io as pio
from sklearn.metrics import r2_score

app = Flask(__name__)

# Load multiple models
# models = {
#     'Linear_Regression': pickle.load(open('Final_Linear.pkl', 'rb')),
#     'Decision_Tree': pickle.load(open('Decision_Tree.pkl', 'rb')),
#     # Add more models as needed
# }

models = {
    'Linear_Regression': pickle.load(open('Final_Linear.pkl', 'rb')),
    'Decision_Tree': pickle.load(open('DecisionTest.pkl', 'rb')),
    # Add more models as needed
}


@app.route('/')
def home():
    return render_template('index.html')



@app.route('/predict', methods=['POST'])
def predict():
    stock_symbol = request.form.get('symbol', '').upper()

    # Get user input for custom values
    custom_open = request.form.get('open')
    custom_high = request.form.get('high')
    custom_low = request.form.get('low')
    custom_close = request.form.get('close')
    custom_volume = request.form.get('volume')

    selected_model_name = request.form.get('model')
    model = models.get(selected_model_name)

    try:
        # If custom values are provided, use them; otherwise, fetch data for the stock symbol
        if custom_open and custom_high and custom_low and custom_close and custom_volume:
            custom_features = np.array([[float(custom_open), float(custom_high), float(custom_low), float(custom_close), float(custom_volume)]]).reshape(1, -1)
            prediction = model.predict(custom_features)[0]
            return render_template('index.html', prediction=prediction, custom=True)

        elif stock_symbol:  
            stock_data = yf.download(stock_symbol, period='1mo', interval='1h') 
            if stock_data.empty:
                return render_template('index.html', error="Could not fetch stock data. Check the stock symbol.")

            predictions = []
            times = []

            # Loop through stock data and predict the next candle's price
            for i in range(len(stock_data)):
                features = stock_data[['Open', 'High', 'Low', 'Close', 'Volume']].iloc[i].values.reshape(1, -1)
                prediction = model.predict(features)[0]
                predictions.append(prediction)
                times.append(stock_data.index[i])

            # Shift the actual prices to align them with the predictions (for the next candle)
            actual_prices_shifted = stock_data['Close'].shift(-1)

            # Remove the last data point from predictions and actual prices to avoid mismatch
            predictions = predictions[:-1]
            actual_prices_shifted = actual_prices_shifted[:-1]
            times = times[:-1]

            # Plot actual vs predicted prices
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=stock_data.index[:-1], y=actual_prices_shifted, mode='lines+markers', name='Actual Price'))
            fig.add_trace(go.Scatter(x=times, y=predictions, mode='lines+markers', name='Predicted Price', marker=dict(color='red', size=10)))

            fig.update_layout(title=f'{stock_symbol} - Actual vs Predicted Price', xaxis_title='Date', yaxis_title='Price')
            plot_html = pio.to_html(fig, full_html=False)

            return render_template('index.html', plot_html=plot_html)
        
        else:
            return render_template('index.html', error="Please select a symbol or provide all custom stock prices.")
    
    except Exception as e:
        return render_template('index.html', error=str(e))
    
@app.route('/compare', methods=['POST'])
def compare():
    stock_symbol = request.form.get('symbol', '').upper()
    selected_model = request.form.get('model')  # Get the model selected by the user

    # Get user input for custom values
    custom_open = request.form.get('open')
    custom_high = request.form.get('high')
    custom_low = request.form.get('low')
    custom_close = request.form.get('close')
    custom_volume = request.form.get('volume')

    predictions = {}
    metrics = {}

    try:
        # If the selected model and all custom inputs are provided
        if selected_model and custom_open and custom_high and custom_low and custom_close and custom_volume:
            # Validate and convert inputs to floats
            try:
                custom_features = np.array([[float(custom_open), float(custom_high), float(custom_low), float(custom_close), float(custom_volume)]])

                # Check if the selected model exists
                if selected_model in models:
                    # Make prediction using the selected model
                    model = models[selected_model]
                    prediction = model.predict(custom_features)[0]
                    predictions[selected_model] = prediction

                    return render_template('index.html', predictions=predictions, metrics=metrics)
                else:
                    return render_template('index.html', error="Selected model not found.")
            except ValueError:
                return render_template('index.html', error="Please enter valid numeric values for all custom prices.")

        # If the stock symbol is provided
        elif stock_symbol:
            stock_data = yf.download(stock_symbol, period='1mo', interval='1h')  
            if stock_data.empty:
                return render_template('index.html', error="Could not fetch stock data. Check the stock symbol.")

            # Prepare features for all available models
            features = stock_data[['Open', 'High', 'Low', 'Close', 'Volume']].values[:-1]  # Exclude the last row for prediction
            actual_prices_shifted = stock_data['Close'].shift(-1)  # Shift the closing prices

            # Ensure we have the same length for predictions and actual values
            predictions = {}
            metrics = {}

            for model_name, model in models.items():
                pred_prices = model.predict(features)  # Get predictions for all features
                
                # Now they should have the same length
                r2 = r2_score(actual_prices_shifted[:-1], pred_prices)  # Compare with shifted actual prices

                # Store predictions and metrics
                predictions[model_name] = pred_prices[-1]  # Last prediction for current candle
                metrics[model_name] = {
                    'R² Score': r2,
                    'Accuracy (%)': r2 * 100,
                }

            # Plot all model predictions
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=stock_data.index[:-1], y=actual_prices_shifted[:-1], mode='lines+markers', name='Actual Price', line=dict(color='blue')))

            # Add predictions for each model
            for model_name, model in models.items():
                pred_prices = model.predict(features)  # Get all predictions to plot
                fig.add_trace(go.Scatter(x=stock_data.index[:-1], y=pred_prices, mode='lines+markers', name=f'{model_name} Prediction'))

            # Update layout
            fig.update_layout(title=f'{stock_symbol} - Model Predictions vs Actual Price',
                              xaxis_title='Date',
                              yaxis_title='Price',
                              legend=dict(x=0, y=1.0))

            plot_html = pio.to_html(fig, full_html=False)
            return render_template('index.html', predictions=predictions, metrics=metrics, plot_html=plot_html)

        else:
            return render_template('index.html', error="Please select a symbol or provide all custom stock prices.")

    except Exception as e:
        print(f"Error occurred: {e}")  # Log the actual error for debugging purposes
        return render_template('index.html', error="An unexpected error occurred. Please try again.")

        # return render_template('index.html', error="An unexpected error occurred. Please try again.")





if __name__ == '__main__':
    app.run(debug=False)



